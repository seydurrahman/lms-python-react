export default function Loading() {
  return (
    <div className="text-center py-10 text-gray-500">
      Loading...
    </div>
  );
}
